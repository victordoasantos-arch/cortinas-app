-- ============================================================================
-- SCHEMA — App de Orçamento, Produção e Estoque de Cortinas
-- Gerado a partir de instrucoes-projeto.md e regras-orcamento-cortinas.md
-- Rodar isso inteiro no SQL Editor do Supabase (projeto novo, do zero)
-- ============================================================================

create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- Numeração sequencial dos orçamentos (regra: começa em 3000, sempre incrementa)
-- ----------------------------------------------------------------------------
create sequence if not exists orcamento_numero_seq start 3000;

-- ----------------------------------------------------------------------------
-- ORÇAMENTOS
-- 1 cliente + N peças. Ciclo de vida: rascunho -> aprovado.
-- Nome e telefone são obrigatórios (regra de trabalho #5).
-- ----------------------------------------------------------------------------
create table if not exists orcamentos (
  id               uuid primary key default gen_random_uuid(),
  numero           int not null unique default nextval('orcamento_numero_seq'),
  cliente_nome     text not null,
  cliente_telefone text not null,
  cliente_cpf      text,
  cliente_cidade   text,
  status           text not null default 'rascunho' check (status in ('rascunho','aprovado')),
  validade_dias    int not null default 15,
  total            numeric(10,2) not null default 0,
  data_criacao     timestamptz not null default now(),
  data_aprovacao   timestamptz,
  criado_por       uuid references auth.users(id)
);

comment on table orcamentos is 'Ficha do vendedor: sempre mostra a conta aberta, nunca só o total (regra #3).';

-- ----------------------------------------------------------------------------
-- PEÇAS — itens de um orçamento (1 por ambiente da lista fixa)
-- ----------------------------------------------------------------------------
create table if not exists pecas (
  id               uuid primary key default gen_random_uuid(),
  orcamento_id     uuid not null references orcamentos(id) on delete cascade,
  local            text not null check (local in ('Sala','Cozinha','Suíte','Banheiro','Quarto 1','Quarto 2','Quarto 3')),
  tipo_peca        text not null check (tipo_peca in ('cortina','persiana')),
  largura          numeric(6,2) not null,
  altura           numeric(6,2) not null,
  configuracao     jsonb not null,   -- camadas, instalação, variante trilho/varão, cromado, tipo de persiana
  detalhe_calculo  jsonb not null,   -- breakdown completo (tecido, acessórios, mão de obra) — o que aparece no orçamento COM preço
  materiais        jsonb not null,   -- consumo de MP agregado dessa peça — usado na baixa de estoque, SEM preço
  valor            numeric(10,2) not null,
  foto_url         text,             -- referência visual (Supabase Storage), nunca usada pra inferir medida
  criado_em        timestamptz not null default now()
);

create index if not exists idx_pecas_orcamento on pecas(orcamento_id);

-- ----------------------------------------------------------------------------
-- ORDENS DE PRODUÇÃO — geradas automaticamente ao aprovar um orçamento
-- Prazo fixo de 30 dias corridos da aprovação (não depende de capacidade).
-- ----------------------------------------------------------------------------
create table if not exists ordens_producao (
  id                     uuid primary key default gen_random_uuid(),
  orcamento_id           uuid not null unique references orcamentos(id),
  numero                 int not null,  -- reaproveita o número do orçamento (1 orçamento = 1 OP)
  status                 text not null default 'aguardando' check (status in ('aguardando','em_producao','pronto','entregue')),
  data_aprovacao         timestamptz not null default now(),
  data_entrega_prevista  date not null,  -- sempre data_aprovacao + 30 dias corridos, fixo
  baixa_materiais_feita  boolean not null default false,
  baixa_materiais_em     timestamptz
);

create index if not exists idx_op_status on ordens_producao(status);

comment on table ordens_producao is 'Ficha de impressão gerada a partir daqui NUNCA mostra preço (regra #3).';

-- ----------------------------------------------------------------------------
-- ESTOQUE DE MATÉRIA-PRIMA
-- Sobe só por entrada manual, desce só pela baixa feita na tela de Produção.
-- ----------------------------------------------------------------------------
create table if not exists estoque_mp (
  id        text primary key,   -- ex: 'linho_flame', 'trilho_simples'
  nome      text not null,
  unidade   text not null,      -- 'm', 'un', 'm²'
  categoria text,               -- Tecido / Estrutura / Acessório / Persiana
  saldo     numeric(10,2) not null default 0,
  minimo    numeric(10,2) not null default 0
);

-- ----------------------------------------------------------------------------
-- MOVIMENTOS DE ESTOQUE — log de toda entrada/saída
-- ----------------------------------------------------------------------------
create table if not exists movimentos_estoque (
  id          uuid primary key default gen_random_uuid(),
  item_id     text not null references estoque_mp(id),
  tipo        text not null check (tipo in ('entrada','saida')),
  quantidade  numeric(10,2) not null,
  origem      text,   -- 'Entrada manual' ou número da OP que gerou a baixa
  criado_em   timestamptz not null default now(),
  criado_por  uuid references auth.users(id)
);

create index if not exists idx_mov_item on movimentos_estoque(item_id);

-- ----------------------------------------------------------------------------
-- Funções de incremento/decremento atômico de saldo (evita corrida entre
-- duas baixas/entradas simultâneas lendo o mesmo saldo desatualizado)
-- ----------------------------------------------------------------------------
create or replace function incrementar_estoque(p_item_id text, p_quantidade numeric)
returns void language sql as $$
  update estoque_mp set saldo = saldo + p_quantidade where id = p_item_id;
$$;

create or replace function decrementar_estoque(p_item_id text, p_quantidade numeric)
returns void language sql as $$
  update estoque_mp set saldo = saldo - p_quantidade where id = p_item_id;
$$;

-- ============================================================================
-- RLS — só equipe autenticada (vendedor/produção) acessa. Sem acesso público.
-- Simples por enquanto: qualquer usuário logado tem acesso total.
-- Se um dia precisar separar permissão de vendedor x produção, isso muda pra
-- policies por role — registrar essa decisão no sistema-mestre.md quando ocorrer.
-- ============================================================================
alter table orcamentos          enable row level security;
alter table pecas               enable row level security;
alter table ordens_producao     enable row level security;
alter table estoque_mp          enable row level security;
alter table movimentos_estoque  enable row level security;

create policy "equipe autenticada" on orcamentos         for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "equipe autenticada" on pecas               for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "equipe autenticada" on ordens_producao      for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "equipe autenticada" on estoque_mp           for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "equipe autenticada" on movimentos_estoque   for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
